 <?php
//get post request and parse into array
$postdata = file_get_contents("php://input");
$data     = array();
parse_str($postdata, $data);


//connect to db
$servername     = "localhost";
$username       = "aimon";
$password       = "";
$conn           = new mysqli($servername, $username, $password, "my_aimon");
//get number of sender (subtract the +)
$data["Sender"] = substr($data["Sender"], 1);
$sender         = $data["Sender"];
//get other data
$body           = $data["Body"];
$date           = $data["Timestamp"];
$platform       = $data["Destination"];
//date of now
$now            = date("Y-m-d H:i:s");

//inserisco il messaggio nella tabella
$query  = "insert into risposte_ricevute (testo,cel, datetime) values ('" . $body . "','" . $sender . "','" . $date . "')";
$result = $conn->query($query);





//mando la 1 domanda (per ora in modo statico con un if)
if ($body == "Aiuto") {
                //controllo che la comunicazione non sia già attiva...
                $query  = "select * from clienti_piattaforma where cel_cliente = '" . $sender . "' and status='0'";
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                                //la comunicazione è gia attiva... stampo l'ultima domanda da promemoria e lo comunico
                                $query  = "select body_text from domande_inviate,domande where domande.id = domande_inviate.id_domanda and n_cell = '" . $sender . "' having max(datetime)";
                                $result = $conn->query($query);
                                while ($row = $result->fetch_assoc()) {
                                                $text = "Attenzione! Comunicazione già in corso. L'ultima domanda è: ";
                                                $text .= $row["body_text"];
                                }
                } else {
                                //la comunicazione non è attiva: mando la prima domanda
                                $query  = "select * from domande where id='1'";
                                $result = $conn->query($query);
                                if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                                $text       = $row["body_text"];
                                                                $id_domanda = $row["id"];
                                                }
                                }
                                $now    = date("Y-m-d H:i:s");
                                $query  = "insert into domande_inviate (n_cell,id_domanda,datetime) values('" . $sender . "','" . $id_domanda . "','" . $now . "')";
                                $result = $conn->query($query);
                                
                                //nuova comunicazione instaurata ------ inserisco num cliente e status (0 comunicazione attiva --- 1 terminata)
                                //in questo modo so se il cliente ha finito di chiedere info... ecc
                                //da aggiungere: terminare comunicazione dopo tot tempo o da messaggio (es premi end per terminare)
                                $query  = "insert into clienti_piattaforma(cel_cliente,id_piattaforma,status,datetime_start) values ('" . $sender . "','0','0','" . $now . "')";
                                $result = $conn->query($query);
                }
} else {
                //altre domande! recupero l'ultima domanda inviata
                $query  = "select id_domanda,datetime from domande_inviate where n_cell = '" . $sender . "' having max(datetime)";
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                                $id_domanda = $row["id_domanda"];
                                }
                                
                }
                //cerco la domanda con id successivo all'ultima inviata
                $query  = "select * from domande where id ='" . ($id_domanda + 1) . "' and '" . $id_domanda . "'<= (select max(id) from domande)";
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                                $text = $row["body_text"];
                                }
                                $now   = date("Y-m-d H:i:s");
                                $query = "insert into domande_inviate (n_cell,id_domanda,datetime) values('" . $sender . "','" . ($id_domanda + 1) . "','" . $now . "')";
                                
                                $result = $conn->query($query);
                } else {
                                //sono finite le domande
                                $text   = "Sono finite le domande! la comunicazione terminerà. Premere 'Aiuto' per iniziare di nuovo.";
                                //inserisco nel db lo status della comunicazione finita (1)
                                $now    = date("Y-m-d H:i:s");
                                $query  = "update clienti_piattaforma set status = '1', datetime_end = '" . $now . "' where cel_cliente = '" . $sender . "' and status='0'";
                                $result = $conn->query($query);
                }
                
}

//Parte che esegue una chiamata http per inviare il messaggio (POST)  ----------- (Credito finito)
/*  
$buffer = array("authlogin" => "joulraven@aimon.it",
"authpasswd" => "ynSinLUn5AvGdGtx5eQdOHN2qR2gNZpW",
"sender" => base64_encode("xzas"),
"body" => base64_encode($text),
"destination" => $sender,
"id_api" => 84);

$url = 'https://secure.apisms.it/http/send_sms';

$options = array(
'http' => array(
'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
'method'  => 'POST',
'content' => http_build_query($buffer)
)
);
$context  = stream_context_create($options);
$ret = file_get_contents($url, false, $context);
*/

//salvo su file il messaggio (per test senza mex)
$fp = fopen("prov.txt", "a");
fwrite($fp, $text);
fclose($fp);
$conn->close();

?> 
get_mex.php
