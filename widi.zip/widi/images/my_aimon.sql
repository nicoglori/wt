-- phpMyAdmin SQL Dump
-- version 4.1.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 26, 2017 at 11:07 PM
-- Server version: 5.6.33-log
-- PHP Version: 5.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_aimon`
--

-- --------------------------------------------------------

--
-- Table structure for table `clienti_piattaforma`
--

CREATE TABLE IF NOT EXISTS `clienti_piattaforma` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cel_cliente` varchar(222) NOT NULL,
  `id_piattaforma` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `datetime_start` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datetime_end` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `domande`
--

CREATE TABLE IF NOT EXISTS `domande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body_text` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `domande`
--

INSERT INTO `domande` (`id`, `body_text`) VALUES
(1, 'Come ti chiami?'),
(2, 'Dove sei?');

-- --------------------------------------------------------

--
-- Table structure for table `domande_inviate`
--

CREATE TABLE IF NOT EXISTS `domande_inviate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `n_cell` varchar(222) NOT NULL,
  `id_domanda` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

-- --------------------------------------------------------

--
-- Table structure for table `piattaforma`
--

CREATE TABLE IF NOT EXISTS `piattaforma` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `n_cell` varchar(222) NOT NULL,
  `titolo` varchar(222) NOT NULL,
  `stato` varchar(222) NOT NULL,
  `lingua` varchar(222) NOT NULL,
  `body_text` varchar(222) NOT NULL,
  `datetime` datetime NOT NULL,
  `id_client` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `risposte_ricevute`
--

CREATE TABLE IF NOT EXISTS `risposte_ricevute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `testo` varchar(222) NOT NULL,
  `cel` varchar(222) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
